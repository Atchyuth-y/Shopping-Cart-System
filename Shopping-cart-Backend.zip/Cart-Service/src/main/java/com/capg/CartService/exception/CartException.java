package com.capg.CartService.exception;

public class CartException extends Exception{
    public CartException(String msg){
        super(msg);
    }
}
