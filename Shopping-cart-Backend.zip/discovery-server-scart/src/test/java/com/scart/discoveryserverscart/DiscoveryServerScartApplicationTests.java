package com.scart.discoveryserverscart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryServerScartApplicationTests {

	@Test
	void contextLoads() {
	}

}
